var linker = angular.module('linker', ['ngRoute', 'ui.router']);

linker.run(['$rootScope', '$state', '$stateParams',
	function($rootScope, $state, $stateParams) {
		$rootScope.$state = $state;
		$rootScope.$stateParams = $stateParams;
	}
]);
linker.config(function($stateProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise("admin/authenticationinfofind//");
	$stateProvider
		.state("admin", {
			url: '/admin',
			views: {
				'left_content': {
					templateUrl: 'templates/leftappcontent.html',
					controller: 'LeftcontentappController',
				},
			},
		})
		
		.state("admin.subsciptinfofind", {
			url: '/subsciptinfofind/{imsi}',
			views: {
				'right_content@': {
					templateUrl: "templates/main/subscriptioninfo/subscriptinfofind.html",
					controller: 'SubscriptInfoFindController',
				},
				
			},
		})
		.state("admin.subsciptinfofind.apnconfiguration", {
			url: 'apnconfiguration/{imsi}',
			views: {
				'right_content@': {
					templateUrl: "templates/main/subscriptioninfo/apnconfiguration.html",
					controller: 'ApnConfigurationController',
				},
				
			},
		})
		.state("admin.authenticationinfofind", {
			url: '/authenticationinfofind/{imsi}/{timeStamp}',
			views: {
				'right_content@': {
					templateUrl: "templates/main/subscriptioninfo/authenticationinfofind.html",
					controller: 'AuthenticationController',
				},
				
			},
		})
		

});
