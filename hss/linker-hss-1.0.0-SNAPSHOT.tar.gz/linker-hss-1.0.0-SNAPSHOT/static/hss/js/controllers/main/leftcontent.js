
linker.controller('LeftcontentappController', function($scope, $location, $rootScope) {
	$scope.navigators = [{
		"name": "Authentication",
		"image": "authenticationinfofind",
		"sref": "admin.authenticationinfofind",
		"ngclass": "active",
	}, {
		"name": "Subscription",
		"image": "subsciptinfofind",
		"sref": "admin.subsciptinfofind",
		"ngclass": "",
	}, ];

	$scope.selectthis = function(Ite) {
		_.each($scope.navigators, function(item) {
			if (item.name != Ite.name) {
				item.ngclass = "";
			} else {
				item.ngclass = "active";
			}
		});
		Ite.value = true;
		var i = $scope.navigators.length;
		for (m = 0; m < i; m++) {
			if ($scope.navigators[m].name != Ite.name) {
				$scope.navigators[m].value = false;
			}
		};

	};
	$scope.subSelectthis = function(name) {
		_.each($scope.navigators, function(item) {
			if (item.sec.name != name) {
				item.sec.ngclass = "";
			} else {
				item.sec.ngclass = "active";
			}
		})

	};

	$scope.setValue = function(Value) {
		Value.sec.value = true;
	};

	function forRefresh() {
		var path = $location.path();
		_.each($scope.navigators, function(item) {
			if (path != "") {
				if (path.split('/')[2] != item.image) {
					item.ngclass = "";
				} else {
					item.ngclass = "active";
				}
			}
		})
	}
	forRefresh();
	$rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
		var path = toState.name;
		_.each($scope.navigators, function(item) {
			if (path != "") {
				if (path != item.sref) {
					item.ngclass = "";
				} else {
					item.ngclass = "active";
				}
			}
		});
		$('.list-group-item').blur();
	});
})

/*linker.controller('LeftcontentadminController', function($scope, $http, $location, $state, $rootScope) {

	$scope.navigators = [{
		"menuName": "Authentication",
		"ngclass": "",
		"menueOrder":1,
		"menueSon":[{
			"menuImage":"find",
			"menuName": "find",
			"ngclass": "authenticationinfofind",
			"menueOrder":11,
			"menuUrl":"admin.authenticationinfofind",
		},],
	}, {
		"menuName": "Subscription info",
		"menueOrder":2,
		"menueSon":[{
			"menuName": "add",
			"ngclass": "",
			"menuImage":"",
			"menueOrder":21,
			"menuUrl":"",
		},{
			"menuName": "find",
			"ngclass": "",
			"menuImage":"subsciptinfofind",
			"menueOrder":22,
			"menuUrl":"admin.subsciptinfofind",
		},{
			"menuName": "Add apn-configuration",
			"ngclass": "",
			"menuImage":"",
			"menueOrder":23,
			"menuUrl":"",
		},{
			"menuName": "Display apn-configuration",
			"ngclass": "",
			"menuImage":"",
			"menueOrder":24,
			"menuUrl":"",
		},],
	}, {
		"menuName": "system",
		"ngclass": "",
		"menueOrder":3,
		"menueSon":[{
			"menuName": "Help",
			"ngclass": "",
			"menuImage":"",
			"menueOrder":31,
			"menuUrl":"",
		},{
			"menuName": "About",
			"ngclass": "",
			"menuImage":"",
			"menueOrder":32,
			"menuUrl":"",
		},],
	}, ];
	forRefresh();
	function forRefresh() {
		var path = $location.path();
		var i = $scope.navigators.length;
		for (m = 0; m < i; m++) {
			var j = $scope.navigators[m].menueSon.length;
			for (n = 0; n < j; n++) {

				if (path != "") {
					if (path.split('/')[2] == $scope.navigators[m].menueSon[n].menuImage) {
						$scope.navigators[m].value = true;
						$scope.navigators[m].menueSon[n].ngclass = true;
						break;
					} else {
						$scope.navigators[m].value = false;
						$scope.navigators[m].menueSon[n].ngclass = false;
					}
				}
			}
		}
	};
	$scope.selectthis = function(Ite) {
		Ite.value = true;
		var i = $scope.navigators.length;
		for (m = 0; m < i; m++) {
			if ($scope.navigators[m].menuName != Ite.menuName) {
				$scope.navigators[m].value = false;
			}
		};
	};
	$scope.subSelectthis = function(subitem) {
		var i = $scope.navigators.length;
		for (m = 0; m < i; m++) {
			var j = $scope.navigators[m].menueSon.length;
			for (n = 0; n < j; n++) {
				u = $location.path();
				if (u != "") {
					$scope.navigators[m].menueSon[n].ngclass = false;
				}
			}
		}
		subitem.ngclass = true;
	};

	
	$rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
		var path = toState.name;
		_.each($scope.navigators, function(item) {
			if (path != "") {
				if (path != item.sref) {
					item.ngclass = "";
				} else {
					item.ngclass = "active";
				}
			}
		});
		$('.list-group-item').blur();
	});
});*/