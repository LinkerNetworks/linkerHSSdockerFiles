linker.controller('GprsDataController', ['$scope', '$window', '$state', '$location', 'webService','$http','responseService',
   function($scope, $window, $state, $location, webService,$http,responseService) {
	$scope.imsi = sessionStorage.gprsdataimsi;
		var initial = function() {
			$scope.getPages();
		};
		
		$scope.addgprsdata = function() {
			$scope.add_control = true;
		};
		$scope.addgprspdpdata = function() {
			$scope.add_pdpcontrol = true;
		};
		$scope.editGprspdpdata = function(data) {
			$scope.edit_control = true;
			$scope.edit_control_data = data;
		};
		$scope.editGprsdata = function(data) {
			$scope.edit_gprs_control = true;
			$scope.edit_gprscontrol_data = data;
		};
		
		$scope.getPages = function() {
			webService.get_data("/getsubbyimsi?imsi=" + $scope.imsi
					
			).then(function(data) {
				$scope.data = data.data;
				},
				function(error) {
					layer.alert("获取subscription失败", {    	 
						icon: 2
					});
				});

		};
		
		
		$scope.deletepdp = function(data,pdp) {
			var title = "你确定删除"+data+"<br>PdpContext吗？";
			layer.confirm(title, {icon: 3, title:'提示'}, function(index){
				
				var url = "/editSub/deletegprspdpdata/" + data;
				var request = {
				    "url": url,
				    "dataType": "json",
				    "method": "POST",
				    "data": JSON.stringify(pdp)
				}
				
				$http(request).success(function(response){
					var reply = response.reply;
					if(reply == 1){
						$scope.getPages();
						layer.alert('操作成功', {
							icon: 1
						});
					}else{
						responseService.errorResponse("操作失败。" + response.replyDesc);
					}
					
				}).error(function(error){
					layer.alert("删除"+data+"失败", {    	 
						icon: 2
					});
				});
				layer.close(index);
				
			});
			
		}
		$scope.deletegprs = function(data) {
			var title = "你确定删除"+data+"<br>GPRSSubscriptData吗？";
			layer.confirm(title, {icon: 3, title:'提示'}, function(index){
				webService.get_data("/editSub/deletegprsdata/" + data
						
				).then(function(data) {
					$scope.getPages();
					layer.alert('操作成功', {
						icon: 1
					});
				},
				function(error) {
					layer.alert("删除"+data+"失败", {    	 
						icon: 2
					});
				});
				  
				layer.close(index);
				
			});
		}
		$scope.totracedata = function(imsi) {
			sessionStorage.tracedataimsi = imsi;
			$location.path("/admin/subsciptinfofind///tracedata" );
		}
		$scope.jumpsubscript = function(imsi) {
			$scope.timeStamp = new Date().getTime();
			$location.path("/admin/subsciptinfofind/"+imsi+"/"+$scope.timeStamp);
		}
		$scope.jump = function(imsi) {
			sessionStorage.imsi = imsi;
		
			$location.path("/admin/subsciptinfofind/apnconfiguration/"+imsi );
		}
		initial();
	}
]);