linker.controller('AuthenticationController', ['$scope', '$window', '$state', '$location', 'webService',
   function($scope, $window, $state, $location, webService) {
        $scope.imsi = _.isUndefined($state.params.imsi) ? "" : $state.params.imsi;
		var initial = function() {
			$scope.data="";
			$scope.getPages();
			
		};
		
		$scope.addauthentication = function() {
			$scope.add_control = true;
		};
		$scope.editauthentication = function(data) {
			$scope.edit_control = true;
			$scope.edit_control_data = data;
		};
		var test = function() {
			var filterNum = /^[\d]{15}$/;
			if ( filterNum.test($scope.imsi) ) {
				return true;
			} else {
				layer.alert('请输入15位正确格式的IMSI', {
					icon: 0
				});
				$scope.spec = "";
				return false
			}
		}
		$scope.getPages = function() {
			webService.get_data("/getauthbyimsi?imsi=" + $scope.imsi
					
			).then(function(data) {
				$scope.data = data.data;
				//$scope.data = {"imsi":"123123123","authType":0,"opString":"45a167ded839b6dfa92d935d77e5c067"};
				},
				function(error) {
					layer.alert("读取authentication失败", {    	 
						icon: 2
					});
				});
		}
		$scope.delete = function(data) {
			var title = "你确定删除"+data+"吗？";
			layer.confirm(title, {icon: 3, title:'提示'}, function(index){
				webService.get_data("/deleteAuth?imsi=" + $scope.imsi
						
				).then(function(data) {
					$scope.getPages();
					layer.alert('操作成功', {
						icon: 1
					});
				},
				function(error) {
					layer.alert("删除"+data+"失败", {    	 
						icon: 2
					});
				});
				  
				layer.close(index);
				
			});
			
		}
		$scope.searchauthentication = function() {
			if (test()) {
				$scope.timeStamp = new Date().getTime();
				$location.path("/admin/authenticationinfofind/" + $scope.imsi+ "/" + $scope.timeStamp );
			}
		};
		
		initial();
	}
]);