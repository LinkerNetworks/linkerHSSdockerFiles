linker.controller('TraceDataController', ['$scope', '$window', '$state', '$location', 'webService',
   function($scope, $window, $state, $location, webService) {
        $scope.imsi = sessionStorage.tracedataimsi;
		var initial = function() {
			$scope.getPages();
		};
		
		$scope.addtracedata = function() {
			$scope.add_control = true;
		};
		$scope.editTradcdata = function(data) {
			$scope.edit_control = true;
			$scope.edit_control_data = data;
		};
		
		$scope.getPages = function() {
			webService.get_data("/getsubbyimsi?imsi=" + $scope.imsi
					
			).then(function(data) {
				$scope.data = data.data;
				},
				function(error) {
					layer.alert("获取subscription失败", {    	 
						icon: 2
					});
				});

		};
		
		$scope.searchsubscription = function() {

			if (test()) {
				$scope.timeStamp = new Date().getTime();
				$location.path("/admin/subsciptinfofind/" + $scope.imsi +"/" + $scope.timeStamp);
			}
		};
		$scope.delete = function(data) {
			var title = "你确定删除"+data+"<br>TraceData吗？";
			layer.confirm(title, {icon: 3, title:'提示'}, function(index){
				webService.get_data("/editSub/deletetracedata/" + data
						
				).then(function(data) {
					$scope.getPages();
					layer.alert('操作成功', {
						icon: 1
					});
				},
				function(error) {
					layer.alert("删除"+data+"失败", {    	 
						icon: 2
					});
				});
				  
				layer.close(index);
				
			});
			
		}
		$scope.jumpsubscript = function(imsi) {
			$scope.timeStamp = new Date().getTime();
			$location.path("/admin/subsciptinfofind/"+imsi+"/"+$scope.timeStamp);
		}
		$scope.togprsdata = function(imsi) {
			sessionStorage.gprsdataimsi = imsi;
			$location.path("/admin/subsciptinfofind///gprsdata" );
		}
		$scope.jump = function(imsi) {
			sessionStorage.imsi = imsi;
		
			$location.path("/admin/subsciptinfofind/apnconfiguration/"+imsi );
		}
		initial();
	}
]);