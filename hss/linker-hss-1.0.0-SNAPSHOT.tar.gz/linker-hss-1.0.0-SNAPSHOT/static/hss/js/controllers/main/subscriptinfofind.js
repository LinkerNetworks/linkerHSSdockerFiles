linker.controller('SubscriptInfoFindController', ['$scope', '$window', '$state', '$location', 'webService',
   function($scope, $window, $state, $location, webService) {
        $scope.imsi = _.isUndefined($state.params.imsi) ? "" : $state.params.imsi;
		var initial = function() {
			$scope.getPages();
		};
		
		$scope.addsubscription = function() {
			$scope.add_control = true;
		};
		$scope.editsubscription = function(data) {
			$scope.edit_control = true;
			$scope.edit_control_data = data;
		};
		$scope.getPages = function() {
			webService.get_data("/getsubbyimsi?imsi=" + $scope.imsi
					
			).then(function(data) {
				$scope.data = data.data;
				},
				function(error) {
					layer.alert("获取subscription失败", {    	 
						icon: 2
					});
				});

		};
		var test = function() {
			var filterNum = /^[\d]{15}$/;
			if ( filterNum.test($scope.imsi) ) {
				return true;
			} else {
				layer.alert('请输入15位正确格式的IMSI', {
					icon: 0
				});
				$scope.spec = "";
				return false
			}
		}
		$scope.searchsubscription = function() {

			if (test()) {
				$scope.timeStamp = new Date().getTime();
				$location.path("/admin/subsciptinfofind/" + $scope.imsi +"/" + $scope.timeStamp);
			}
		};
		$scope.delete = function(data) {
			var title = "你确定删除"+data+"吗？";
			layer.confirm(title, {icon: 3, title:'提示'}, function(index){
				webService.get_data("/deleteSub?imsi=" + $scope.imsi
						
				).then(function(data) {
					$scope.getPages();
					layer.alert('操作成功', {
						icon: 1
					});
				},
				function(error) {
					layer.alert("删除"+data+"失败", {    	 
						icon: 2
					});
				});
				  
				layer.close(index);
				
			});
			
		}
		$scope.totracedata = function(imsi) {
			sessionStorage.tracedataimsi = imsi;
			$location.path("/admin/subsciptinfofind///tracedata" );
		}
		$scope.togprsdata = function(imsi) {
			sessionStorage.gprsdataimsi = imsi;
			$location.path("/admin/subsciptinfofind///gprsdata" );
		}
		$scope.toapnconfig = function(imsi) {
			sessionStorage.apnconfigimsi = imsi;
			$location.path("/admin/subsciptinfofind///apnconfig" );
		}
		initial();
	}
]);