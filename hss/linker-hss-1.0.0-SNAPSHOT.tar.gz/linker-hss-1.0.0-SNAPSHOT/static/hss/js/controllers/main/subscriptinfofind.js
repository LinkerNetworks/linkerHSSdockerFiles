linker.controller('SubscriptInfoFindController', ['$scope', '$window', '$state', '$location', 'webService',
   function($scope, $window, $state, $location, webService) {
        $scope.imsi = _.isUndefined($state.params.imsi) ? "" : $state.params.imsi;
		var initial = function() {
			$scope.getPages();
		};
		
		$scope.addsubscription = function() {
			$scope.add_control = true;
		};
		/*$scope.editchannel = function(data) {
			$scope.edit_control = true;
			$scope.edit_control_data = data;
		};
		$scope.channelswitch = function(data) {
			$scope.channel_switch = true;
			$scope.channel_switch_data = data;
		}*/
		$scope.getPages = function() {
			/*webService.get_data("/op/channel/queryChannel?imsi=" + $scope.imsi
				
			).then(function(data) {
					$scope.datas = data.pagedListDTO.records;
				},
				function(error) {
					responseService.errorResponse("读取subscription失败");
				});*/

			$scope.data = "";
		};
		var test = function() {
			var filterNum = /^[\d]{15}$/;
			if ( filterNum.test($scope.imsi) ) {
				return true;
			} else {
				layer.alert('请输入15位正确格式的IMSI', {
					icon: 0
				});
				$scope.spec = "";
				return false
			}
		}
		$scope.searchsubscription = function() {

			if (test()) {
				$location.path("/admin/subsciptinfofind/" + $scope.imsi );
			}
		};
		
		$scope.jump = function(imsi) {
			sessionStorage.imsi = imsi;
			$location.path("/admin/subsciptinfofind/apnconfiguration/"+imsi);
		}
		initial();
	}
]);