linker.controller('ApnConfigurationController', ['$scope', '$window', '$state', '$location', 'webService','$http','responseService',
   function($scope, $window, $state, $location, webService,$http,responseService) {
	$scope.imsi = sessionStorage.apnconfigimsi;
	var initial = function() {
		$scope.getPages();
	};
	
	$scope.addapnprofile = function() {
		$scope.add_control = true;
	};
	$scope.addapnconfig = function() {
		$scope.add_apncontrol = true;
	};
	$scope.editapnconfig = function(data) {
		$scope.edit_control = true;
		$scope.edit_control_data = data;
	};
	$scope.editApnprofile = function(data) {
		$scope.edit_apnf_control = true;
		$scope.edit_apnfcontrol_data = data;
	};
	$scope.addspecificapn = function(data) {
		$scope.edit_specificapn_control = true;
		$scope.edit_specificapn_data = data;
	};
	$scope.remove = function(item,items,data) {
		items.splice(items.indexOf(item),1)
		$scope.edit_specificapn_deletecontrol = true;
		$scope.edit_specificapn_data = data;
		$scope.edit_specificapn_delete = items;
	};
	
	$scope.getPages = function() {
		webService.get_data("/getsubbyimsi?imsi=" + $scope.imsi
				
		).then(function(data) {
			$scope.data = data.data;
			},
			function(error) {
				layer.alert("获取subscription失败", {    	 
					icon: 2
				});
			});

	};
	
	
	$scope.deleteapnconf = function(data,apnconf) {
		var title = "你确定删除"+data+"<br>ApnConfiguration吗？";
		layer.confirm(title, {icon: 3, title:'提示'}, function(index){
			
			var url = "/editSub/deleteapnconf/" + data;
			var request = {
			    "url": url,
			    "dataType": "json",
			    "method": "POST",
			    "data": JSON.stringify(apnconf)
			}
			
			$http(request).success(function(response){
				var reply = response.reply;
				if(reply == 1){
					$scope.getPages();
					layer.alert('操作成功', {
						icon: 1
					});
				}else{
					responseService.errorResponse("操作失败。" + response.replyDesc);
				}
				
			}).error(function(error){
				layer.alert("删除"+data+"失败", {    	 
					icon: 2
				});
			});
			layer.close(index);
			
		});
		
	}
	$scope.deleteapn = function(data) {
		var title = "你确定删除"+data+"<br>ApnConfigurationProfile吗？";
		layer.confirm(title, {icon: 3, title:'提示'}, function(index){
			webService.get_data("/editSub/deleteapn/" + data
					
			).then(function(data) {
				$scope.getPages();
				layer.alert('操作成功', {
					icon: 1
				});
			},
			function(error) {
				layer.alert("删除"+data+"失败", {    	 
					icon: 2
				});
			});
			  
			layer.close(index);
			
		});
	}
	
	$scope.totracedata = function(imsi) {
		sessionStorage.tracedataimsi = imsi;
		$location.path("/admin/subsciptinfofind///tracedata" );
	}
	$scope.jumpsubscript = function(imsi) {
		$scope.timeStamp = new Date().getTime();
		$location.path("/admin/subsciptinfofind/"+imsi+"/"+$scope.timeStamp);
	}
	$scope.jump = function(imsi) {
		sessionStorage.imsi = imsi;
	
		$location.path("/admin/subsciptinfofind/apnconfiguration/"+imsi );
	}
	initial();
	}
]);