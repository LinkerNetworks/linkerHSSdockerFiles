linker.controller('ApnConfigurationController', ['$scope', '$window', '$state', '$location', 'webService',
   function($scope, $window, $state, $location, webService) {
        $scope.imsi = _.isUndefined($state.params.imsi) ? "" : $state.params.imsi;
		var initial = function() {
			$scope.getPages();
		};
		
		$scope.addsubscription = function() {
			$scope.add_control = true;
		};
		/*$scope.editchannel = function(data) {
			$scope.edit_control = true;
			$scope.edit_control_data = data;
		};
		$scope.channelswitch = function(data) {
			$scope.channel_switch = true;
			$scope.channel_switch_data = data;
		}*/
		$scope.getPages = function() {
			/*webService.get_data("/op/channel/queryChannel?imsi=" + $scope.imsi
				
			).then(function(data) {
					$scope.datas = data.pagedListDTO.records;
				},
				function(error) {
					responseService.errorResponse("读取subscription失败");
				});*/

			$scope.data = "";
		};
		
		initial();
	}
]);