function authenticResource($http, $q) {
	var addAuthentic = function(conditions) {
		var url = "/addAuth?imsi="+conditions.imsi+"&authType="+conditions.authtype+"&op="+conditions.op+"&opc="
		+conditions.opc+"&k="+conditions.k+"&amf="+conditions.amf+"&sqn="+conditions.sqn;
		
		var request = {
			url: url,
		};

		var deferred = $q.defer();
		$http(request).success(function(response) {
			deferred.resolve(response);
		}).error(function(error) {
			deferred.reject(error);
		});
		return deferred.promise;
	}
	var editAuthentics = function(conditions) {
		var deferred = $q.defer();
		var url = "/editAuth?imsi="+conditions.imsi+"&authType="+conditions.authType+"&op="+conditions.op+"&opc="
		+conditions.opc+"&k="+conditions.k+"&amf="+conditions.amf+"&sqn="+conditions.sqn;
		
		var request = {
			url: url,
		};
		$http(request).success(function(response) {
			deferred.resolve(response);
		}).error(function(error) {
			deferred.reject(error);
		});
		return deferred.promise;
	}
	return {
		"editAuthentics": editAuthentics,
		"addAuthentic":addAuthentic
	}
}
linker.factory('authenticService', ['$http', '$q', authenticResource]);