linker.directive('editauthentic', function(check,$filter, webService,responseService,authenticService) {
	return {
		templateUrl: './templates/directives/editauthentic.html',
		scope: {
			control: "=",
			refresh: '&refreshFn',
			editcontroldata: '='
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){

				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.authentic = new Object();
				$scope.data =[];
				$scope.check = new Object();
				$scope.authentic.imsi = $scope.editcontroldata.imsi;
				$scope.authentic.authtype = $scope.editcontroldata.authType;
				$scope.data[3]=$scope.editcontroldata.opString;
				$scope.data[6]=$scope.editcontroldata.opcString;
				$scope.data[9]=$scope.editcontroldata.k;
				$scope.data[12]=$scope.editcontroldata.amfString;
				$scope.data[15]=$scope.editcontroldata.sqn;
				
				$scope.check.imsi = function() {
					if (!$scope.authentic.imsi) {
						$scope.alert.imsi = true;
						$scope.alertInfo.imsi = "请输入imsi";
					} else {
						var imsilen = $scope.authentic.imsi;
						if( $scope.authentic.imsi.match(/^[\d]{15}$/) == null){
							$scope.alert.imsi = true;
							$scope.alertInfo.imsi = "IMSI必须为15位数字";
						}else{
							$scope.alert.imsi = false;
							$scope.alertInfo.imsi = "";
						}
					}
				};
				$scope.check.authtype = function() {
					if (!$scope.authentic.authtype) {
						$scope.alert.authtype = true;
						$scope.alertInfo.authtype = "请选择Auth Mode";
					} else {
						$scope.alert.authtype = false;
						$scope.alertInfo.authtype = "";
					}
				};
				$scope.check.empty = function(temp) {
					if (!$scope.data[temp]) {
						$scope.data[temp+1] = true;
						$scope.data[temp+2] = "不能为空";
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
			
				$scope.send = function() {
					$scope.check.imsi();
					$scope.check.authtype();
					$scope.check.empty(9);
					$scope.check.empty(12);
					$scope.check.empty(15);
					if($scope.alert.imsi||$scope.alert.authtype||$scope.data[10]||$scope.data[13]||$scope.data[16]){
						return
					}
					authenticService.editAuthentics({
						imsi : $scope.authentic.imsi,
						authType : $scope.authentic.authType,
						op : $scope.data[3],
						opc : $scope.data[6],
						k : $scope.data[9],
						amf : $scope.data[12],
						sqn :  $scope.data[15]
						
					}).then(function(data){
						if(data.code == 200){
							$scope.close();
							$scope.refresh();
							layer.alert('操作成功', {
								icon: 1
							});
						}else {
							responseService.errorResponse("操作失败。" + data.desc);
						}
						
					},
					function(error) {
						responseService.errorResponse("操作失败。" + error);
					});
			};
			$scope.close = function() {
				$scope.control = false;
			}
			}

			}
		}
})
