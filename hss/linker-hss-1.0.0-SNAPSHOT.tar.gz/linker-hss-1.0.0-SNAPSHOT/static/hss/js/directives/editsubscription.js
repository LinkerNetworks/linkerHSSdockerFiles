linker.directive('editsubscription', function(check,$filter, webService,$http,responseService) {
	return {
		templateUrl: './templates/directives/editsubscription.html',
		scope: {
			control: "=",
			refresh: '&refreshFn',
			editcontroldata: '='
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){

				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.subscription = new Object();
				$scope.data =[];
				$scope.check = new Object();
				angular.copy($scope.editcontroldata, $scope.subscription);
				$scope.subscription.subscriber_status = $scope.editcontroldata.subscriber_status+"";
				$scope.subscription.ics_indicator = $scope.editcontroldata.ics_indicator+"";
				$scope.subscription.network_access_mode = $scope.editcontroldata.network_access_mode+"";
				$scope.subscription.roaming_restricted_due_to_unsupported_feature = $scope.editcontroldata.roaming_restricted_due_to_unsupported_feature+"";
				$scope.check.imsi = function() {
					if (!$scope.authentic.imsi) {
						$scope.alert.imsi = true;
						$scope.alertInfo.imsi = "请输入imsi";
					} else {
						var imsilen = $scope.authentic.imsi;
						if( $scope.authentic.imsi.match(/^[\d]{15}$/) == null){
							$scope.alert.imsi = true;
							$scope.alertInfo.imsi = "IMSI必须为15位数字";
						}else{
							$scope.alert.imsi = false;
							$scope.alertInfo.imsi = "";
						}
					}
				};
				
			
				$scope.send = function() {
					$scope.check.imsi
					if($scope.alert.imsi == true){
						return
					}
					var data = {
						"imsi": $scope.subscription.imsi,
						"subscriber_status": $scope.subscription.subscriber_status,
						"msisdn": $scope.subscription.msisdn,
						"stn_sr": $scope.subscription.stn_sr,
						"ics_indicator": $scope.subscription.ics_indicator,
						"network_access_mode": $scope.subscription.network_access_mode,
						"operator_determined_barring": $scope.subscription.operator_determined_barring,
						"hplmn_odb": $scope.subscription.hplmn_odb,
						"regional_subscription_zone_code_string": $scope.subscription.regional_subscription_zone_code_string,
						"access_restriction_data": $scope.subscription.access_restriction_data,
						"apn_oi_replacement": $scope.subscription.apn_oi_replacement,
						"_3gpp_charging_characteristics": $scope.subscription._3gpp_charging_characteristics,
						"rat_frequency_selection_priority_id": $scope.subscription.rat_frequency_selection_priority_id,
						"roaming_restricted_due_to_unsupported_feature": $scope.subscription.roaming_restricted_due_to_unsupported_feature,
						"teleservice_list":{"ts_code_string":$scope.subscription.teleservice_list.ts_code_string}, 
						"call_barring_info_list":{"ss_code_string":$scope.subscription.call_barring_info_list.ss_code_string}, 
						"ambr":{
							"max_requested_bandwidth_ul": $scope.subscription.ambr.max_requested_bandwidth_ul,
							"max_requested_bandwidth_dl": $scope.subscription.ambr.max_requested_bandwidth_dl
						}
						
					};
					var url = "/editSub";
					var request = {
					    "url": url,
					    "dataType": "json",
					    "method": "POST",
					    "data": JSON.stringify(data)
					}
					
					$http(request).success(function(response){
						var reply = response.reply;
						if(reply == 1){
							$scope.close();
							$scope.refresh();
							layer.alert('操作成功', {
								icon: 1
							});
						}else{
							responseService.errorResponse("操作失败。" + response.replyDesc);
						}
						
					}).error(function(error){
							responseService.errorResponse("操作失败。" + error.replyDesc);
						});
							
				};
				$scope.close = function() {
					$scope.control = false;
				}
			}

		}
	}
})
