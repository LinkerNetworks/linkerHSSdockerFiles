linker.directive('addapnconfiguration', function(check, webService, $compile, $filter,$http,responseService) {
	return {
		templateUrl: './templates/directives/addapnconfigurationprofile.html',
		scope: {
			"control": "=",
			refresh: '&refreshFn',
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){
				
				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.data =[];
				$scope.check = new Object();
				
				$scope.check.empty = function(temp) {
					if (!$scope.data[temp]) {
						$scope.data[temp+1] = true;
						$scope.data[temp+2] = "不能为空";
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				$scope.check.emptyselect = function(temp) {
					if (!$scope.data[temp]) {
						$scope.data[temp+1] = true;
						$scope.data[temp+2] = "请选择";
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				$scope.check.number = function(temp){
					if ($scope.data[temp]) {
						var reg=  /^[-+]?\d*$/ ;
						if (!reg.test($scope.data[temp])){
							$scope.data[temp+1] = true;
							$scope.data[temp+2] = "必须是整数";
						}else {
							$scope.data[temp+1] = false;
							$scope.data[temp+2] = "";
						}
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				$scope.send = function() {
					$scope.check.number(3);
					$scope.check.number(9);
					if($scope.data[4]||$scope.data[10]){
						return
					}
					$scope.check.empty(3);
					$scope.check.emptyselect(6);
					$scope.check.empty(9);
					$scope.check.emptyselect(15);
					$scope.check.empty(18);
				
					if($scope.data[4]||$scope.data[7]||$scope.data[10]||$scope.data[16]||$scope.data[19]||$scope.data[22]||$scope.data[40]||$scope.data[58]||$scope.data[61]){
						return
					}
					var data = {
							"context_identifier":$scope.data[3],
							"all_apn_configurations_included_indicator":$scope.data[6],
							"apn_configurations": [{
								"context_identifier":$scope.data[9],
								"served_party_ip_addresses_str":$scope.data[12],
								"pdn_type": $scope.data[15],
								"service_selection": $scope.data[18],
								"vplmn_dynamic_address_allowed": $scope.data[21],
								"visited_network_identifier": $scope.data[24],
								"pdn_gw_allocation_type": $scope.data[27],
								"_3gpp_charging_characteristics": $scope.data[30],
								"apn_oi_replacement": $scope.data[33],
								"eps_subscribed_qos_profile":{
									"qos_class_identifier": $scope.data[36],
									"allocation_retention_priority":{
										"priority_level": $scope.data[39],
										"pre_emption_capability": $scope.data[42],
										"pre_emption_Vulnerability": $scope.data[45]
									}
									
								},
								"mip6_agent_info":{
									"mip_home_agent_address_str": $scope.data[48],
									"mip_home_agent_host":{
										"destinationHost": $scope.data[51],
										"destinationRealm": $scope.data[54]
									}
								
								},
								"ambr":{
									"max_requested_bandwidth_ul":$scope.data[57],
									"max_requested_bandwidth_dl": $scope.data[60]
								},
								"specific_apn_info":[{
									"service_selection": $scope.data[63],
									"visited_network_identifier": $scope.data[66],
									"mip6AgentInfo":{
										"mip_home_agent_address_str": $scope.data[69],
										"mip_home_agent_host":{
											"destinationHost": $scope.data[72],
											"destinationRealm": $scope.data[75]
										}
									}
								}]
							}]
						
					};
					var url = "/editSub/saveapn/"+sessionStorage.apnconfigimsi;
					var request = {
					    "url": url,
					    "dataType": "json",
					    "method": "POST",
					    "data": JSON.stringify(data)
					}
					
					$http(request).success(function(response){
						var reply = response.reply;
						if(reply == 1){
							$scope.close();
							$scope.refresh();
							layer.alert('操作成功', {
								icon: 1
							});
						}else{
							responseService.errorResponse("操作失败。" + response.replyDesc);
						}
						
					}).error(function(error){
							responseService.errorResponse("操作失败。" +error.replyDesc);
						});
							
				}
			$scope.close = function() {
				$scope.control = false;
			}
			
			
			
			}
		}
	}
})


