linker.directive('editgprsdata', function(check, webService, $compile, $filter,$http,responseService) {
	return {
		templateUrl: './templates/directives/editgprsdata.html',
		scope: {
			"control": "=",
			refresh: '&refreshFn',
			editcontroldata: '='
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){
				
				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.data = [];
				$scope.check = new Object();
				$scope.data[3] = $scope.editcontroldata.complete_data_list_included_indicator+"";
				
				
			$scope.send = function() {
				webService.get_data("/editSub/editgprsdata?imsi=" +sessionStorage.gprsdataimsi+"&cdlii="+$scope.data[3]
						
				).then(function(data) {
					$scope.close();
					$scope.refresh();
					layer.alert('操作成功', {
						icon: 1
					});
				
				},function(error) {
						layer.alert("操作失败", {    	 
							icon: 2
						});
					});
						
			}
			$scope.close = function() {
				$scope.control = false;
			}
			
			
			}
		}
	}
})


