linker.directive('addgprspdpcontextdata', function(check, webService, $compile, $filter,$http,responseService) {
	return {
		templateUrl: './templates/directives/addgprspdpdata.html',
		scope: {
			"control": "=",
			refresh: '&refreshFn',
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){
				
				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.data = [];
				$scope.check = new Object();

				$scope.check.empty = function(temp) {
					if (!$scope.data[temp]) {
							$scope.data[temp+1] = true;
							$scope.data[temp+2] = "不能为空";
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				$scope.check.sexadecimal = function(temp){
					if ($scope.data[temp]) {
						var reg=  /^[0-9a-fA-F]*$/ ;
						if (!reg.test($scope.data[temp]) || $scope.data[temp].length % 2 != 0){
							$scope.data[temp+1] = true;
							$scope.data[temp+2] = "必须是十六进制的偶位数";
						}else {
							$scope.data[temp+1] = false;
							$scope.data[temp+2] = "";
						}
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				$scope.check.number = function(temp){
					if ($scope.data[temp]) {
						var reg=  /^[-+]?\d*$/ ;
						if (!reg.test($scope.data[temp])){
							$scope.data[temp+1] = true;
							$scope.data[temp+2] = "必须是整数";
						}else {
							$scope.data[temp+1] = false;
							$scope.data[temp+2] = "";
						}
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				
			$scope.send = function() {
				$scope.check.number(3);
				$scope.check.sexadecimal(6);
				$scope.check.sexadecimal(12);
				if($scope.data[4]||$scope.data[7]||$scope.data[13]){
					return
				}
				$scope.check.empty(3);
				$scope.check.empty(6);
				$scope.check.empty(12);
				$scope.check.empty(18);

				if($scope.data[4]||$scope.data[7]||$scope.data[13]||$scope.data[16]||$scope.data[19]||$scope.data[25]){
					return
				}
				var data = {
							"context_identifier":$scope.data[3],
							"pdp_type":$scope.data[6],
							"pdp_address":$scope.data[9],
							"qos_subscribed": $scope.data[12],
							"vplmn_dynamic_address_allowed": $scope.data[15],
							"service_selection": $scope.data[18],
							"_3gpp_charging_characteristics": $scope.data[21],
							"ext_pdp_type": $scope.data[24],
							"ext_pdp_address": $scope.data[27]
					
				};
				var url = "/editSub/gprssavepdpdata/"+sessionStorage.gprsdataimsi;
				var request = {
				    "url": url,
				    "dataType": "json",
				    "method": "POST",
				    "data": JSON.stringify(data)
				}
				
				$http(request).success(function(response){
					var reply = response.reply;
					if(reply == 1){
						$scope.close();
						$scope.refresh();
						layer.alert('操作成功', {
							icon: 1
						});
					}else{
						responseService.errorResponse("操作失败。" + response.replyDesc);
					}
					
				}).error(function(error){
						responseService.errorResponse("操作失败。" +error.replyDesc);
					});
						
			}
			$scope.close = function() {
				$scope.control = false;
			}
			
			
			}
		}
	}
})


