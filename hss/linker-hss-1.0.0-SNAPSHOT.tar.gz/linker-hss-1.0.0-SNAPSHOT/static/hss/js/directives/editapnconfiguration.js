linker.directive('editapnconfiguration', function(check, webService, $compile, $filter,$http,responseService) {
	return {
		templateUrl: './templates/directives/editapnconfiguration.html',
		scope: {
			"control": "=",
			refresh: '&refreshFn',
			editcontroldata: '='
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){
				
				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.data = [];
				$scope.specific_apn_info = [];
				$scope.check = new Object();
				
				$scope.data[9] = $scope.editcontroldata.context_identifier;
				$scope.data[12] = $scope.editcontroldata.served_party_ip_addresses_str;
				$scope.data[15] = $scope.editcontroldata.pdn_type+"";
				$scope.data[18] = $scope.editcontroldata.service_selection;
				$scope.data[21] = $scope.editcontroldata.vplmn_dynamic_address_allowed;
				$scope.data[24] = $scope.editcontroldata.visited_network_identifier;
				$scope.data[27] = $scope.editcontroldata.pdn_gw_allocation_type+"";
				$scope.data[30] = $scope.editcontroldata._3gpp_charging_characteristics;
				$scope.data[33] = $scope.editcontroldata.apn_oi_replacement;
				$scope.data[36] = $scope.editcontroldata.eps_subscribed_qos_profile.qos_class_identifier+"";
				$scope.data[39] = $scope.editcontroldata.eps_subscribed_qos_profile.allocation_retention_priority.priority_level;
				$scope.data[42] = $scope.editcontroldata.eps_subscribed_qos_profile.allocation_retention_priority.pre_emption_capability+"";
				$scope.data[45] = $scope.editcontroldata.eps_subscribed_qos_profile.allocation_retention_priority.pre_emption_Vulnerability+"";
				$scope.data[48] = $scope.editcontroldata.mip6_agent_info.mip_home_agent_address_str;
				$scope.data[51] = $scope.editcontroldata.mip6_agent_info.mip_home_agent_host.destinationHost;
				$scope.data[54] = $scope.editcontroldata.mip6_agent_info.mip_home_agent_host.destinationRealm;
				$scope.data[57] = $scope.editcontroldata.ambr.max_requested_bandwidth_ul;
				$scope.data[60] = $scope.editcontroldata.ambr.max_requested_bandwidth_dl;
				$scope.specific_apn_info = $scope.editcontroldata.specific_apn_info;
				
				$scope.check.empty = function(temp) {
					if (!$scope.data[temp]) {
						$scope.data[temp+1] = true;
						$scope.data[temp+2] = "不能为空";
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				$scope.check.number = function(temp){
					if ($scope.data[temp]) {
						var reg=  /^[-+]?\d*$/ ;
						if (!reg.test($scope.data[temp])){
							$scope.data[temp+1] = true;
							$scope.data[temp+2] = "必须是整数";
						}else {
							$scope.data[temp+1] = false;
							$scope.data[temp+2] = "";
						}
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				$scope.check.emptyselect = function(temp) {
					if (!$scope.data[temp]) {
						$scope.data[temp+1] = true;
						$scope.data[temp+2] = "请选择";
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				$scope.send = function() {
					$scope.check.empty(9);
					$scope.check.emptyselect(15);
					$scope.check.empty(18);
					if($scope.data[10]||$scope.data[16]||$scope.data[19]||$scope.data[22]||$scope.data[40]||$scope.data[58]||$scope.data[61]){
						return
					}
					var data = {
							"context_identifier":$scope.data[9],
							"served_party_ip_addresses_str":$scope.data[12],
							"pdn_type": $scope.data[15],
							"service_selection": $scope.data[18],
							"vplmn_dynamic_address_allowed": $scope.data[21],
							"visited_network_identifier": $scope.data[24],
							"pdn_gw_allocation_type": $scope.data[27],
							"_3gpp_charging_characteristics": $scope.data[30],
							"apn_oi_replacement": $scope.data[33],
							"eps_subscribed_qos_profile":{
								"qos_class_identifier": $scope.data[36],
								"allocation_retention_priority":{
									"priority_level": $scope.data[39],
									"pre_emption_capability": $scope.data[42],
									"pre_emption_Vulnerability": $scope.data[45]
								}
								
							},
							"mip6_agent_info":{
								"mip_home_agent_address_str": $scope.data[48],
								"mip_home_agent_host":{
									"destinationHost": $scope.data[51],
									"destinationRealm": $scope.data[54]
								}
							
							},
							"ambr":{
								"max_requested_bandwidth_ul":$scope.data[57],
								"max_requested_bandwidth_dl": $scope.data[60]
							},
							"specific_apn_info":$scope.specific_apn_info
						
					};
					var url = "/editSub/editapnconfig/"+sessionStorage.apnconfigimsi;
					var request = {
					    "url": url,
					    "dataType": "json",
					    "method": "POST",
					    "data": JSON.stringify(data)
					}
					
					$http(request).success(function(response){
						var reply = response.reply;
						if(reply == 1){
							$scope.close();
							$scope.refresh();
							layer.alert('操作成功', {
								icon: 1
							});
						}else{
							responseService.errorResponse("操作失败。" + response.replyDesc);
						}
						
					}).error(function(error){
							responseService.errorResponse("操作失败。" +error.replyDesc);
						});
							
				}
			$scope.close = function() {
				$scope.control = false;
			}
		
			
			}
		}
	}
})

