linker.directive('deletespecificapn', function(check, webService, $compile, $filter,$http,responseService) {
	return {
		templateUrl: './templates/directives/deletespecificapn.html',
		scope: {
			"control": "=",
			refresh: '&refreshFn',
			editcontroldata: '=',
			editspecificapncontroldata: '=',
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){
				
				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.data = [];
				$scope.check = new Object();
				$scope.specific_apn_info = [];
				$scope.specific_apn_info = $scope.editspecificapncontroldata;
				
				
			$scope.send = function() {
				var data = {
						"context_identifier":$scope.editcontroldata.context_identifier,
						"served_party_ip_addresses_str":$scope.editcontroldata.served_party_ip_addresses_str,
						"pdn_type": $scope.editcontroldata.pdn_type,
						"service_selection": $scope.editcontroldata.service_selection,
						"vplmn_dynamic_address_allowed": $scope.editcontroldata.vplmn_dynamic_address_allowed,
						"visited_network_identifier": $scope.editcontroldata.visited_network_identifier,
						"pdn_gw_allocation_type": $scope.editcontroldata.pdn_gw_allocation_type,
						"_3gpp_charging_characteristics": $scope.editcontroldata._3gpp_charging_characteristics,
						"apn_oi_replacement": $scope.editcontroldata.apn_oi_replacement,
						"eps_subscribed_qos_profile":{
							"qos_class_identifier": $scope.editcontroldata.eps_subscribed_qos_profile.qos_class_identifier,
							"allocation_retention_priority":{
								"priority_level": $scope.editcontroldata.eps_subscribed_qos_profile.allocation_retention_priority.priority_level,
								"pre_emption_capability": $scope.editcontroldata.eps_subscribed_qos_profile.allocation_retention_priority.pre_emption_capability,
								"pre_emption_Vulnerability": $scope.editcontroldata.eps_subscribed_qos_profile.allocation_retention_priority.pre_emption_Vulnerability
							}
							
						},
						"mip6_agent_info":{
							"mip_home_agent_address_str": $scope.editcontroldata.mip6_agent_info.mip_home_agent_address_str,
							"mip_home_agent_host":{
								"destinationHost": $scope.editcontroldata.mip6_agent_info.mip_home_agent_host.destinationHost,
								"destinationRealm":$scope.editcontroldata.mip6_agent_info.mip_home_agent_host.destinationRealm
							}
						
						},
						"ambr":{
							"max_requested_bandwidth_ul":$scope.editcontroldata.ambr.max_requested_bandwidth_ul,
							"max_requested_bandwidth_dl":$scope.editcontroldata.ambr.max_requested_bandwidth_dl
						},
						"specific_apn_info":$scope.specific_apn_info
					
				};
				var url = "/editSub/editapnconfig/"+sessionStorage.apnconfigimsi;
				var request = {
				    "url": url,
				    "dataType": "json",
				    "method": "POST",
				    "data": JSON.stringify(data)
				}
				
				$http(request).success(function(response){
					var reply = response.reply;
					if(reply == 1){
						$scope.close();
						$scope.refresh();
						layer.alert('操作成功', {
							icon: 1
						});
					}else{
						responseService.errorResponse("操作失败。" + response.replyDesc);
					}
					
				}).error(function(error){
						responseService.errorResponse("操作失败。" +error.replyDesc);
					});
						
			}
			$scope.close = function() {
				$scope.control = false;
			}
			
			
			}
		}
	}
})


