linker.directive('addsubscription', function(check, webService, $compile, $filter) {
	return {
		templateUrl: './templates/directives/addsubscription.html',
		scope: {
			"control": "=",
			refresh: '&refreshFn',
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){
				
				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.subscription = new Object();
				$scope.check = new Object();
				
			
				$scope.check.imsi = function() {
					if (!$scope.subscription.imsi) {
						$scope.alert.imsi = true;
						$scope.alertInfo.imsi = "请输入imsi";
					} else {
						var imsilen = $scope.subscription.imsi;
						if( $scope.subscription.imsi.match(/^[\d]{15}$/) == null){
							$scope.alert.imsi = true;
							$scope.alertInfo.imsi = "IMSI必须为15位数字";
						}else{
							$scope.alert.imsi = false;
							$scope.alertInfo.imsi = "";
						}
					}
				};
			
				/*$scope.send = function() {
				for (var i in $scope.check) {
					$scope.check[i]();
					if ($scope.alert[i] == true)
						return;
				}
				mifiUserInfoService.addMifiRes({
					mifiPhoneNo : $scope.subscription.mifiPhoneNo,
					moType : $scope.subscription.moType,
					province : $scope.subscription.province,
					groupName : $scope.subscription.groupName,
					cardType : $scope.subscription.cardType,
					activeState : $scope.subscription.activeState,
					concurrency : $scope.subscription.concurrency,
					imsi : $scope.subscription.imsi
				}).then(function(data){
					if(data.code == 200){
						$scope.close();
						$scope.refresh();
						layer.alert('操作成功', {
							icon: 1
						});
					}else {
						responseService.errorResponse("操作失败。" + data.desc);
					}
					
				},
				function(error) {
					responseService.errorResponse("操作失败。" + error);
				});
			};*/
			$scope.close = function() {
				$scope.control = false;
			}
			$scope.addpdpcontext = function() {
				var pdpconhtml = $("#pdpcontext").clone();
				pdpconhtml.find("button").text("-");
				pdpconhtml.find("button").attr("onclick","cancel(this)")
				var html = "<tr style='height:30px'>"+pdpconhtml.html()+"</tr>";
				$("#pdpcontext").after(html)
			}
			
			}
		}
	}
})

function cancel(param){
	param.parentNode.parentNode.remove();
}
