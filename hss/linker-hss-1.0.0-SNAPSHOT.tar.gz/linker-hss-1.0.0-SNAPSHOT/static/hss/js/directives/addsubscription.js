linker.directive('addsubscription', function(check, webService, $compile, $filter,$http,responseService) {
	return {
		templateUrl: './templates/directives/addsubscription.html',
		scope: {
			"control": "=",
			refresh: '&refreshFn',
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){
				
				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.subscription = new Object();
				$scope.check = new Object();
				$scope.data = [];
			
				$scope.check.imsi = function() {
					if (!$scope.subscription.imsi) {
						$scope.alert.imsi = true;
						$scope.alertInfo.imsi = "请输入imsi";
					} else {
						var imsilen = $scope.subscription.imsi;
						if( $scope.subscription.imsi.match(/^[\d]{15}$/) == null){
							$scope.alert.imsi = true;
							$scope.alertInfo.imsi = "IMSI必须为15位数字";
						}else{
							$scope.alert.imsi = false;
							$scope.alertInfo.imsi = "";
						}
					}
				};
			
				$scope.check.sexadecimal = function(temp){
					if ($scope.data[temp]) {
						var reg=  /^[0-9a-fA-F]*$/ ;
						if (!reg.test($scope.data[temp]) || $scope.data[temp].length % 2 != 0){
							$scope.data[temp+1] = true;
							$scope.data[temp+2] = "必须是十六进制偶位数";
						}else {
							$scope.data[temp+1] = false;
							$scope.data[temp+2] = "";
						}
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				$scope.check.number = function(temp){
					if ($scope.data[temp]) {
						var reg= /^[-+]?\d*$/;
						if (!reg.test($scope.data[temp])){
							$scope.data[temp+1] = true;
							$scope.data[temp+2] = "必须是整数";
						}else {
							$scope.data[temp+1] = false;
							$scope.data[temp+2] = "";
						}
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				
				$scope.check.phoneNumber = function(){
					if ($scope.subscription.msisdn) {
						var reg= /^\d*$/;
						if (!reg.test($scope.subscription.msisdn) ||$scope.subscription.msisdn.length !=11 ){
							$scope.alert.Msisdn = true;
							$scope.alertInfo.Msisdn = "请填写正确格式的手机号";
						}else {
							$scope.alert.Msisdn = false;
							$scope.alertInfo.Msisdn = "";
						}
					} else {
						$scope.alert.Msisdn = false;
						$scope.alertInfo.Msisdn = "";
					}
				};
				
			$scope.send = function() {
				$scope.check.imsi();
				if($scope.alert.imsi == true){
					return
				}
				$scope.check.phoneNumber();
				if($scope.alert.Msisdn == true){
					return
				}
				$scope.check.number(3);
				$scope.check.number(6);
				$scope.check.number(9);
				$scope.check.number(12);
				if($scope.data[4]||$scope.data[7]||$scope.data[10]||$scope.data[13]){
					return
				}
				var data = {
					"imsi": $scope.subscription.imsi,
					"subscriber_status": $scope.subscription.status,
					"msisdn": $scope.subscription.msisdn,
					"stn_sr": $scope.subscription.stnsr,
					"ics_indicator": $scope.subscription.icsindicator,
					"network_access_mode": $scope.subscription.networkaccessmode,
					"operator_determined_barring": $scope.data[3],
					"hplmn_odb":  $scope.data[6],
					"regional_subscription_zone_code_string": $scope.subscription.rszcs,
					"access_restriction_data":  $scope.data[9],
					"apn_oi_replacement": $scope.subscription.aor,
					"_3gpp_charging_characteristics": $scope.subscription._3cc,
					"rat_frequency_selection_priority_id": $scope.data[12],
					"roaming_restricted_due_to_unsupported_feature": $scope.subscription.rrdtuf,
					"teleservice_list":{"ts_code_string":$scope.subscription.tltc}, 
					"call_barring_info_list":{"ss_code_string":$scope.subscription.clsc}, 
					"ambr":{
						"max_requested_bandwidth_ul": $scope.subscription.ambrmul,
						"max_requested_bandwidth_dl": $scope.subscription.ambrmdl
					}
					
				};
				var url = "/addSub";
				var request = {
				    "url": url,
				    "dataType": "json",
				    "method": "POST",
				    "data": JSON.stringify(data)
				}
				
				$http(request).success(function(response){
					var reply = response.reply;
					if(reply == 1){
						$scope.close();
						$scope.refresh();
						layer.alert('操作成功', {
							icon: 1
						});
					}else{
						responseService.errorResponse("操作失败。" + response.replyDesc);
					}
					
				}).error(function(error){
						responseService.errorResponse("操作失败。" + error.replyDesc);
					});
						
			}
			$scope.close = function() {
				$scope.control = false;
			}
			
			}
		}
	}
})
