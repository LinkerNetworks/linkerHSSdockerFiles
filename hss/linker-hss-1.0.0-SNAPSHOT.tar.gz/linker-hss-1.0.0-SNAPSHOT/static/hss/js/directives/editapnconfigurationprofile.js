linker.directive('editapnprofile', function(check, webService, $compile, $filter,$http,responseService) {
	return {
		templateUrl: './templates/directives/editapnconfigurationprofile.html',
		scope: {
			"control": "=",
			refresh: '&refreshFn',
			editcontroldata: '='
		},
		restrict: 'ACEM',
		link: function($scope) {
			$scope.init = function(){
				
				$scope.alert = new Object();
				$scope.alertInfo = new Object();
				$scope.data = [];
				$scope.check = new Object();
				$scope.data[3] = $scope.editcontroldata.context_identifier;
				$scope.data[6] = $scope.editcontroldata.all_apn_configurations_included_indicator+"";
				$scope.check.empty = function(temp) {
					if (!$scope.data[temp]) {
						$scope.data[temp+1] = true;
						$scope.data[temp+2] = "不能为空";
					} else {
						$scope.data[temp+1] = false;
						$scope.data[temp+2] = "";
					}
				};
				
			$scope.send = function() {
				$scope.check.empty(3);
			
				if($scope.data[4]){
					return
				}
				webService.get_data("/editSub/editapnconfprofile?imsi=" +sessionStorage.gprsdataimsi+"&aacii="+$scope.data[6]
				+"&ci="+$scope.data[3]
						
				).then(function(data) {
					$scope.close();
					$scope.refresh();
					layer.alert('操作成功', {
						icon: 1
					});
				
				},function(error) {
						layer.alert("操作失败", {    	 
							icon: 2
						});
					});
						
			}
			$scope.close = function() {
				$scope.control = false;
			}
			
			
			}
		}
	}
})


